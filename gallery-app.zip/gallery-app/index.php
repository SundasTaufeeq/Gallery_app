<?php include "config.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Gallery App</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="bg-light">
  <div class="container py-5">
    <h2 class="text-center mb-4">Image Gallery</h2>

    <!-- Upload Form -->
    <form action="upload.php" method="POST" enctype="multipart/form-data" class="mb-4">
      <div class="input-group">
        <input type="file" name="image" class="form-control" required />
        <button type="submit" name="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>

    <!-- Messages -->
    <?php
    if (isset($_GET['msg'])) {
      if ($_GET['msg'] == 'success') {
        echo '<div class="alert alert-success">Image uploaded successfully!</div>';
      } elseif ($_GET['msg'] == 'deleted') {
        echo '<div class="alert alert-info">Image deleted successfully!</div>';
      }
    }
    ?>

    <!-- Gallery Display -->
    <div class="row">
      <?php
      $result = $conn->query("SELECT * FROM images ORDER BY uploaded_on DESC");
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo '<div class="col-md-3 mb-4">
                  <div class="card shadow-sm">
                    <img src="uploads/' . htmlspecialchars($row['filename']) . '" class="card-img-top" alt="Image" />
                    <div class="card-body d-flex justify-content-between align-items-center">
                      <p class="card-text text-muted small mb-0">Uploaded on: ' .
                        date("d M Y, h:i A", strtotime($row['uploaded_on'])) .
                      '</p>
                      <form method="POST" action="delete.php" onsubmit="return confirm(\'Are you sure you want to delete this image?\');">
                        <input type="hidden" name="id" value="' . intval($row['id']) . '" />
                        <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                    </div>
                  </div>
                </div>';
        }
      } else {
        echo '<p class="text-center">No images uploaded yet.</p>';
      }
      ?>
    </div>
  </div>
</body>
</html>
