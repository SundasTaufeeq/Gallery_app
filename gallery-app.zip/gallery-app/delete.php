<?php
include "config.php";

if (isset($_POST['delete']) && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Get filename from database for this id
    $stmt = $conn->prepare("SELECT filename FROM images WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($filename);
    if ($stmt->fetch()) {
        $stmt->close();

        // Delete the image file from server
        $filePath = 'uploads/' . $filename;
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete record from database
        $stmtDel = $conn->prepare("DELETE FROM images WHERE id = ?");
        $stmtDel->bind_param("i", $id);
        $stmtDel->execute();
        $stmtDel->close();

        header("Location: index.php?msg=deleted");
        exit();
    } else {
        echo "Image not found.";
    }
} else {
    echo "Invalid request.";
}
?>
